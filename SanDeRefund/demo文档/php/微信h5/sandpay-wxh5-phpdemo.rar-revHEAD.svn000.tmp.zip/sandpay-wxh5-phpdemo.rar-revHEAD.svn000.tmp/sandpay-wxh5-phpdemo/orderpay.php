<?php 
require('common.php');
date_default_timezone_set("Asia/Shanghai");

$prikey = loadPk12Cert(PRI_KEY_PATH,CERT_PWD);
$pubkey = loadX509Cert(PUB_KEY_PATH);   

    $data = array(
         'head' => array(
            'version' => '1.0',
            'method' => 'sandpay.trade.pay',
            'productId' => '00000025',
            'accessType' => '1',
            'mid' => '填写正式商户号',
            'channelType' => '07',
            'reqTime' => date('YmdHis', time())
         ),
         'body' => array(
            'orderCode' => '0000000001',
            'totalAmount' => '000000000012',//0.12元
            'subject' => '微信h5支付',
            'body' => "测试",
            'txnTimeOut' => "20181230000000",
            'payMode' => "sand_wxh5",
            'payExtra' => json_encode(array('ip'=> '客户端的真实IP','sceneInfo' => '可随意填写')),
            'clientIp' => "196.168.22.171",
            'notifyUrl' => "填写异步通知地址(需要群里报备)",
            'frontUrl' => "https://www.baidu.com"
            ) 
    );
    $sign = sign($data,$prikey);

    $post = array(
        'charset' => 'utf-8',
        'signType' => '01',
        'data' => json_encode($data),
        'sign' => $sign
   );

    $result = http_post_json(API_HOST.'/order/pay',$post);

    parse_str(urldecode($result),$arr);
    
    $str=$arr['data']."&package=".$arr['package'];
    $arr['data']=str_replace(array(" ","　","\t","\n","\r"),array("","","","",""),$str);

    //验签
    verify($arr['data'], $arr['sign'],$pubkey);

    $data = json_decode($arr['data'],320);
    
       if ($data['head']['respCode']  == "000000" ) {
            $credential = str_replace(array('"{','}"'),array('{','}'),stripslashes($data['body']['credential']));
        }else{
           print_r($arr['data']);
        }

     }else{
        print_r(json_encode($arr,320));
     }
    
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="renderer" content="webkit" />
    <title>Insert title here</title>
    <script type="text/javascript" src="scripts/jquery-1.7.2.min.js"></script>
</head>
<body>
<script>
    function wap_pay() {
        var responseText = $("#credential").text();
        console.log(responseText);
        var str = <?php echo $credential;?>;
        location.href = str.mwebUrl;
    }
</script>
<script>
    window.onload=function(){
        wap_pay();
    };
</script>
</html>