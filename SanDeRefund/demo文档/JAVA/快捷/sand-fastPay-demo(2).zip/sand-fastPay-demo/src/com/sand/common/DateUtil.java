package com.sand.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

/**
 * 日期工具类
 * @author moon
 *
 */
public class DateUtil {
	
	public static final String FORMAT_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
	
	public static final String FORMAT_YYYYMMDD = "yyyyMMdd";
	
    public static final String FORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	
    public static final String formatDate(Date date, String pattern) {
        String v = null;
        try {
            if (date == null)
                return null;
            SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
            v = dateFormat.format(date);
        } catch (Exception e) {
            // do nothing
        }
        return v;
    }
    
    public static String fDate_YYYYMMDDHHMMSS(Date date) {
        return formatDate(date, FORMAT_YYYYMMDDHHMMSS);
    }
    
    public static String fDate_YYYY_MM_DD_HH_MM_SS(Date date){
    	return formatDate(date, FORMAT_YYYY_MM_DD_HH_MM_SS);
    }
    
	public static Date parseDate(String date, String pattern) {
		if (StringUtils.isEmpty(pattern) || StringUtils.isEmpty(date)) {
			return null;
		}
		Date parseDate= null;
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		try {
			parseDate= format.parse(date);
		} catch (ParseException e) {
			// do nothing
		}
		return parseDate;
	}
	
	public static Date pDate_YYYYMMDDHHMMSS(String datestr) {
		return parseDate(datestr, FORMAT_YYYYMMDDHHMMSS);
	}
	
	public static Date pDate_YYYYMMDD(String datestr) {
		return parseDate(datestr, FORMAT_YYYYMMDD);
	}
	
}
