package com.sand.fastPay.stdPay.servlet;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.com.sandpay.cashier.sdk.util.CertUtil;
import cn.com.sandpay.cashier.sdk.util.CryptoUtil;

/**
 * 标准快捷
 * @author moon
 *
 */
public class StdPayServlet extends HttpServlet {
	
	private static final Logger logger = LoggerFactory.getLogger(StdPayServlet.class);

	private static final long serialVersionUID = 1L;
	
	@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		logger.info("StdPayServlet post start >>>");

        Map<String, String[]> params = req.getParameterMap();
        Map<String, String> map = new HashMap<String, String>();
        for (String key : params.keySet()) {
            String[] values = params.get(key);
            if (values.length > 0) {
                map.put(key, values[0]);
            }
        }
		
		// 组后台报文
		JSONObject head = new JSONObject();
		head.put("version", map.get("version"));
		head.put("method", map.get("method"));
		head.put("productId", map.get("productId"));
		head.put("accessType", map.get("accessType"));
		head.put("mid", map.get("mid"));
		head.put("plMid", map.get("plMid"));
		head.put("channelType", map.get("channelType"));
		head.put("reqTime", map.get("reqTime"));

		JSONObject body = new JSONObject();
		body.put("userId", map.get("userId"));
		body.put("applyNo", map.get("applyNo"));
		body.put("notifyUrl", map.get("notifyUrl"));
		body.put("frontUrl", map.get("frontUrl"));
		body.put("extend", map.get("extend"));
		
		JSONObject data = new JSONObject();
		data.put("head", head);
		data.put("body", body);
		
		try {
			String reqSign = URLEncoder.encode(new String(
					Base64.encodeBase64(CryptoUtil.digitalSign(JSON.toJSONString(data).getBytes("UTF-8"), 
							CertUtil.getPrivateKey(), "SHA1WithRSA"))), "UTF-8");
			JSONObject respJson = new JSONObject();
			respJson.put("data", JSON.toJSONString(data));
			respJson.put("sign", reqSign);// 签名串
			resp.getOutputStream().print(respJson.toString());
		} catch (Exception e) {
			logger.error("StdPayServlet post error <<<", e);
		}
    }
	
}
