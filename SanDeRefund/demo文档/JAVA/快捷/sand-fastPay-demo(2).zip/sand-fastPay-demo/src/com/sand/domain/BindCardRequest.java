package com.sand.domain;

/**
 * 快速绑卡请求对象
 * 
 * @author moon
 *
 */
public class BindCardRequest extends PubRequest {

	private static final long serialVersionUID = 1L;

	private String userId;
	private String applyNo;
	private String cardNo;
	private String userName;
	private String phoneNo;
	private String certificateType;
	private String certificateNo;
	private String creditFlag;
	private String checkNo;
	private String checkExpiry;
	private String notifyUrl;
	private String extend;

	public BindCardRequest() {
		super();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getApplyNo() {
		return applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getCertificateNo() {
		return certificateNo;
	}

	public void setCertificateNo(String certificateNo) {
		this.certificateNo = certificateNo;
	}

	public String getCreditFlag() {
		return creditFlag;
	}

	public void setCreditFlag(String creditFlag) {
		this.creditFlag = creditFlag;
	}

	public String getCheckNo() {
		return checkNo;
	}

	public void setCheckNo(String checkNo) {
		this.checkNo = checkNo;
	}

	public String getCheckExpiry() {
		return checkExpiry;
	}

	public void setCheckExpiry(String checkExpiry) {
		this.checkExpiry = checkExpiry;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

	@Override
	public String toString() {
		return "BindCardRequest [userId=" + userId + ", applyNo=" + applyNo + ", cardNo=" + cardNo + ", userName="
				+ userName + ", phoneNo=" + phoneNo + ", certificateType=" + certificateType + ", certificateNo="
				+ certificateNo + ", creditFlag=" + creditFlag + ", checkNo=" + checkNo + ", checkExpiry=" + checkExpiry
				+ ", notifyUrl=" + notifyUrl + ", extend=" + extend + "]";
	}

}
