package com.sand.common;

/**
 * 杉德公共参数
 * 
 * @author moon
 *
 */
public class SandConstants {
	
	public static final String FILE_NAME = "sand.properties";
	
	
	public static final String API_BIND_CARD_URL = "sand.apiBindCardUrl";
	public static final String API_APPLY_BIND_CARD_URL = "sand.apiApplyBindCardUrl";
	public static final String API_CONFIRM_BIND_CARD_URL = "sand.apiConfirmBindCardUrl";
	public static final String API_UNBIND_CARD_URL = "sand.apiUnbindCardUrl";
	public static final String API_SMS_URL = "sand.apiSmsUrl";
	public static final String API_PAY_URL = "sand.apiPayUrl";
	
	public static final String QUICK_INDEX_URL = "sand.quickIndexUrl";
	
	public static final String STD_INDEX_URL = "sand.stdIndexUrl";
	public static final String STD_UNBIND_CARD_URL = "sand.stdUnbindCardUrl";
	public static final String STD_SMS_URL = "sand.stdSmsUrl";
	public static final String STD_PAY_URL = "sand.stdPayUrl";
	
	public static final String MID_PRI_CERT_PATH = "sand.midPriCertPath";
	public static final String MID_PRI_CERT_PWD = "sand.midPriCertPwd";
	public static final String SAND_PUB_CERT_PATH = "sand.sandPubCertPath";
	
	

}
