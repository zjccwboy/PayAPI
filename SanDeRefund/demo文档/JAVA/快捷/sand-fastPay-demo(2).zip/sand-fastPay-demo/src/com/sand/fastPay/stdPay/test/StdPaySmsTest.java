package com.sand.fastPay.stdPay.test;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sand.common.AbstractTest;
import com.sand.common.SandConfig;
import com.sand.domain.PubRequest;
import com.sand.domain.SmsRequest;

import cn.com.sandpay.cashier.sdk.util.DateUtil;

/**
 * 标准快捷-短信发送接口示例
 *
 * @author moon
 */
public class StdPaySmsTest extends AbstractTest {

	private final Logger logger = LoggerFactory.getLogger(StdPaySmsTest.class);

	/*
     * 发送支付短信请求URL
     */
    private static final String URL = SandConfig.getConfig().getStdSmsUrl();


    /**
     * 标准快捷短信发送接口调用示例
     * 说明：
     * 1、商户接入需加载公私钥到项目中
     * 2、封装调用杉德服务端接口，具体参数说明请参考接入文档
     * 3、POST请求杉德服务端
     * 4、验证杉德返回数据签名
     */
    @Test
    public void payTest() {
        try {

            // 组织HEAD域
        	PubRequest requestHead = new PubRequest();
            requestHead.setVersion("1.0");
            requestHead.setMethod("sandPay.fastPay.common.sms");
            requestHead.setProductId("00000017");
            requestHead.setAccessType("1");
            requestHead.setMid("10020025");
            requestHead.setPlMid("");
            requestHead.setChannelType("07");
            requestHead.setReqTime(DateUtil.getCurrentDate14());

            // 组织BODY域
            SmsRequest requestBody = new SmsRequest();
            requestBody.setUserId("0000011111");
            requestBody.setOrderCode(DateUtil.getCurrentDate14() + "001");
            requestBody.setPhoneNo("13800001111");
            requestBody.setBid("SDSMP00000001002002520170831091339706229");
            requestBody.setExtend("");
            doPost(requestHead, requestBody, URL);
        } catch (Exception e) {
        	logger.error("发送支付短信失败失败,{}",e);
        }
    }

}
