package com.sand.fastPay.apiPay.test;

import java.util.Date;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sand.common.AbstractTest;
import com.sand.common.DateUtil;
import com.sand.common.SandConfig;
import com.sand.domain.PayRequest;
import com.sand.domain.PubRequest;

/**
 * API支付示例
 *
 * @author moon
 */
public class ApiPayPayTest extends AbstractTest {

	private final Logger logger = LoggerFactory.getLogger(ApiPayPayTest.class);

    /*
     * 支付请求URL
     */
    private static final String URL = SandConfig.getConfig().getApiPayUrl();

    /**
     * API支付接口调用示例
     * 说明：
     * 1、商户接入需加载公私钥到项目中
     * 2、封装调用杉德服务端接口，具体参数说明请参考接入文档
     * 3、POST请求杉德服务端
     * 4、验证杉德返回数据签名
     */
    @Test
    public void payTest() {
        try {
            // 组织HEAD域
        	PubRequest requestHead = new PubRequest();
            requestHead.setVersion("1.0");
            requestHead.setMethod("sandPay.fastPay.apiPay.pay");
            requestHead.setProductId("00000018");
            requestHead.setAccessType("1");
            requestHead.setMid("10020025");
            requestHead.setPlMid("");
            requestHead.setChannelType("07");
            requestHead.setReqTime(DateUtil.fDate_YYYYMMDDHHMMSS(new Date()));

            // 组织BODY域
            PayRequest requestBody = new PayRequest();
            requestBody.setUserId("0000011111");
            requestBody.setBid("SDSMP00000001002002520170831085735234772");
            requestBody.setPhoneNo("13800001111");
            requestBody.setSmsCode("111111");
            requestBody.setOrderCode("20170831085831001");	// 同发送支付短信的订单号
            requestBody.setOrderTime(DateUtil.fDate_YYYYMMDDHHMMSS(new Date()));
            requestBody.setTotalAmount("000000000005");
            requestBody.setSubject("test subject");
            requestBody.setBody("test body desc");
            requestBody.setCurrencyCode("156");
            requestBody.setNotifyUrl("http://127.0.0.1/test");
            requestBody.setClearCycle("0"); // 0-T1, 1-T0, 2-D0
            requestBody.setExtend("");
            doPost(requestHead, requestBody, URL);
        } catch (Exception e) {
        	logger.error("支付失败,{}",e);
        }
    }
}
