package com.sand.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 杉德配置
 * 
 * @author moon
 *
 */
public class SandConfig {
	
	private final Logger logger = LoggerFactory.getLogger(SandConfig.class);

	/*
	 * API快捷-快速绑卡请求URL
	 */
	private String apiBindCardUrl;
	/*
	 * API快捷-申请绑卡请求URL
	 */
	private String apiApplyBindCardUrl;
	/*
	 * API快捷-确认绑卡请求URL
	 */
	private String apiConfirmBindCardUrl;
	/*
	 * API快捷-解绑卡请求URL
	 */
	private String apiUnbindCardUrl;
	/*
	 * API快捷-发送支付短信请求URL
	 */
	private String apiSmsUrl;
	/*
	 * API快捷-支付请求URL
	 */
	private String apiPayUrl;

	/*
	 * 一键快捷-入口URL
	 */
	private String quickIndexUrl;

	/*
	 * 标准快捷-入口URL
	 */
	private String stdIndexUrl;

	/*
	 * 标准快捷-解绑卡URL
	 */
	private String stdUnbindCardUrl;
	
	/*
	 * 标准快捷-发送支付短信URL
	 */
	private String stdSmsUrl;
	
	/*
	 * 标准快捷-支付URL
	 */
	private String stdPayUrl;
	
	/*
	 * 商户私钥路径 
	 */
	private String midPriCertPath;
	
	/*
	 * 商户私钥密码
	 */
	private String midPriCertPwd;
	
	/*
	 * 杉德公钥路径
	 */
	private String sandPubCertPath;
	
	private static SandConfig config = new SandConfig();
	
	private Properties properties;
	
	private SandConfig() {
		super();
	}
	
	/**
	 * 获取config对象.
	 * @return
	 */
	public static SandConfig getConfig() {
		return config;
	}

	/**
	 * 从文件读取配置文件
	 */
	public void loadConfigFromSrc() {
		InputStream in = getClass().getResourceAsStream("/conf/sand.properties");  
        properties = new Properties();  
        try {
        	if(null != in) {
        		properties.load(in);  
        	}
        	loadProperties(properties);
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
	}
	

	/**
	 * 加载配置文件
	 * @param properties
	 */
	private void loadProperties(Properties pro) {
		logger.info("开始从配置文件中加载配置项");
		String value = null;
		
		value = pro.getProperty(SandConstants.API_BIND_CARD_URL);
		if(StringUtils.isNotBlank(value)) {
			this.apiBindCardUrl = value.trim();
			logger.info("配置项: api快捷-快速绑卡URL[apiBindCardUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.API_APPLY_BIND_CARD_URL);
		if(StringUtils.isNotBlank(value)) {
			this.apiApplyBindCardUrl = value.trim();
			logger.info("配置项: api快捷-申请绑卡URL[apiApplyBindCardUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.API_CONFIRM_BIND_CARD_URL);
		if(StringUtils.isNotBlank(value)) {
			this.apiConfirmBindCardUrl = value.trim();
			logger.info("配置项: api快捷-确认绑卡URL[apiConfirmBindCardUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.API_UNBIND_CARD_URL);
		if(StringUtils.isNotBlank(value)) {
			this.apiUnbindCardUrl = value.trim();
			logger.info("配置项: api快捷-解绑卡URL[apiUnbindCardUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.API_SMS_URL);
		if(StringUtils.isNotBlank(value)) {
			this.apiSmsUrl = value.trim();
			logger.info("配置项: api快捷-发送支付短信URL[apiSmsUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.API_PAY_URL);
		if(StringUtils.isNotBlank(value)) {
			this.apiPayUrl = value.trim();
			logger.info("配置项: api快捷-支付URL[apiPayUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.QUICK_INDEX_URL);
		if(StringUtils.isNotBlank(value)) {
			this.quickIndexUrl = value.trim();
			logger.info("配置项: 一键快捷-入口URL[quickIndexUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.STD_INDEX_URL);
		if(StringUtils.isNotBlank(value)) {
			this.stdIndexUrl = value.trim();
			logger.info("配置项: 标准快捷-入口URL[stdIndexUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.STD_UNBIND_CARD_URL);
		if(StringUtils.isNotBlank(value)) {
			this.stdUnbindCardUrl = value.trim();
			logger.info("配置项: 标准快捷-解绑卡URL[stdUnbindCardUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.STD_SMS_URL);
		if(StringUtils.isNotBlank(value)) {
			this.stdSmsUrl = value.trim();
			logger.info("配置项: 标准快捷-发送支付短信URL[stdSmsUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.STD_PAY_URL);
		if(StringUtils.isNotBlank(value)) {
			this.stdPayUrl = value.trim();
			logger.info("配置项: 标准快捷-支付URL[stdPayUrl]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.MID_PRI_CERT_PATH);
		if(StringUtils.isNotBlank(value)) {
			this.midPriCertPath = value.trim();
			logger.info("配置项: 商户私钥证书路径[midPriCertPath]已加载==>{}", value);
		}
		
		value = pro.getProperty(SandConstants.MID_PRI_CERT_PWD);
		if(StringUtils.isNotBlank(value)) {
			this.midPriCertPwd = value.trim();
			logger.info("配置项: 商户私钥证书密码[midPriCertPwd]已加载==>");
		}
		
		value = pro.getProperty(SandConstants.SAND_PUB_CERT_PATH);
		if(StringUtils.isNotBlank(value)) {
			this.sandPubCertPath = value.trim();
			logger.info("配置项: 杉德公钥证书路径[sandPubCertPath]已加载==>{}", value);
		}
	}

	public String getApiBindCardUrl() {
		return apiBindCardUrl;
	}

	public void setApiBindCardUrl(String apiBindCardUrl) {
		this.apiBindCardUrl = apiBindCardUrl;
	}

	public String getApiApplyBindCardUrl() {
		return apiApplyBindCardUrl;
	}

	public void setApiApplyBindCardUrl(String apiApplyBindCardUrl) {
		this.apiApplyBindCardUrl = apiApplyBindCardUrl;
	}

	public String getApiConfirmBindCardUrl() {
		return apiConfirmBindCardUrl;
	}

	public void setApiConfirmBindCardUrl(String apiConfirmBindCardUrl) {
		this.apiConfirmBindCardUrl = apiConfirmBindCardUrl;
	}

	public String getApiUnbindCardUrl() {
		return apiUnbindCardUrl;
	}

	public void setApiUnbindCardUrl(String apiUnbindCardUrl) {
		this.apiUnbindCardUrl = apiUnbindCardUrl;
	}

	public String getApiSmsUrl() {
		return apiSmsUrl;
	}

	public void setApiSmsUrl(String apiSmsUrl) {
		this.apiSmsUrl = apiSmsUrl;
	}

	public String getApiPayUrl() {
		return apiPayUrl;
	}

	public void setApiPayUrl(String apiPayUrl) {
		this.apiPayUrl = apiPayUrl;
	}

	public String getQuickIndexUrl() {
		return quickIndexUrl;
	}

	public void setQuickIndexUrl(String quickIndexUrl) {
		this.quickIndexUrl = quickIndexUrl;
	}

	public String getStdIndexUrl() {
		return stdIndexUrl;
	}

	public void setStdIndexUrl(String stdIndexUrl) {
		this.stdIndexUrl = stdIndexUrl;
	}

	public String getStdUnbindCardUrl() {
		return stdUnbindCardUrl;
	}

	public void setStdUnbindCardUrl(String stdUnbindCardUrl) {
		this.stdUnbindCardUrl = stdUnbindCardUrl;
	}

	public String getStdSmsUrl() {
		return stdSmsUrl;
	}

	public void setStdSmsUrl(String stdSmsUrl) {
		this.stdSmsUrl = stdSmsUrl;
	}

	public String getStdPayUrl() {
		return stdPayUrl;
	}

	public void setStdPayUrl(String stdPayUrl) {
		this.stdPayUrl = stdPayUrl;
	}

	public String getMidPriCertPath() {
		return midPriCertPath;
	}

	public void setMidPriCertPath(String midPriCertPath) {
		this.midPriCertPath = midPriCertPath;
	}

	public String getMidPriCertPwd() {
		return midPriCertPwd;
	}

	public void setMidPriCertPwd(String midPriCertPwd) {
		this.midPriCertPwd = midPriCertPwd;
	}

	public String getSandPubCertPath() {
		return sandPubCertPath;
	}

	public void setSandPubCertPath(String sandPubCertPath) {
		this.sandPubCertPath = sandPubCertPath;
	}

}
