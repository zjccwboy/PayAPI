package com.sand.fastPay.stdPay.test;

import java.util.Date;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sand.common.AbstractTest;
import com.sand.common.DateUtil;
import com.sand.common.SandConfig;
import com.sand.domain.PubRequest;
import com.sand.domain.UnbindCardRequest;

/**
 * 标准快捷-解绑卡接口示例
 * @author moon
 *
 */
public class StdPayUnBindCardTest extends AbstractTest {

	private final Logger logger = LoggerFactory.getLogger(StdPayUnBindCardTest.class);

	/*
     * 解绑卡请求URL
     */
    private static final String URL = SandConfig.getConfig().getStdUnbindCardUrl();


    /**
     * 解绑卡接口调用示例
     * 说明：1、商户接入需加载公私钥到项目中
     *       2、封装调用杉德服务端接口，具体参数说明请参考接入文档
     *       3、POST请求杉德服务端
     *       4、验证杉德返回数据签名
     */
    @Test
    public void createOrderTest() {

        try {
            // 组织HEAD域
        	PubRequest requestHead = new PubRequest();
        	requestHead.setVersion("1.0");
        	requestHead.setMethod("sandPay.fastPay.stdPay.unbindCard");
        	requestHead.setProductId("00000017");
            requestHead.setAccessType("1");
            requestHead.setMid("10020025");
            requestHead.setPlMid("");
            requestHead.setChannelType("07");
            requestHead.setReqTime(DateUtil.fDate_YYYYMMDDHHMMSS(new Date()));

            // 组织BODY域
            UnbindCardRequest requestBody = new UnbindCardRequest();
            requestBody.setUserId("0000011111");
            requestBody.setApplyNo("000000" + String.valueOf(Math.round(Math.random() * 899999 + 100000)));
            requestBody.setBid("SDSMP00000001002002520170831091339706229");
            requestBody.setNotifyUrl("http://127.0.0.1/test");
            requestBody.setExtend("");
            doPost(requestHead, requestBody, URL);
        } catch (Exception e) {
            logger.error("解绑卡失败,{}",e);
        }
    }
}
