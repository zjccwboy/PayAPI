package com.sand.domain;

/**
 * 确认绑卡请求对象
 * 
 * @author moon
 *
 */
public class ConfirmBindCardRequest extends PubRequest {

	private static final long serialVersionUID = 1L;
	private String userId;
	private String sdMsgNo;
	private String phoneNo;
	private String smsCode;
	private String notifyUrl;
	private String extend;

	public ConfirmBindCardRequest() {
		super();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSdMsgNo() {
		return sdMsgNo;
	}

	public void setSdMsgNo(String sdMsgNo) {
		this.sdMsgNo = sdMsgNo;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getSmsCode() {
		return smsCode;
	}

	public void setSmsCode(String smsCode) {
		this.smsCode = smsCode;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

	@Override
	public String toString() {
		return "ConfirmBindCardRequest [userId=" + userId + ", sdMsgNo=" + sdMsgNo + ", phoneNo=" + phoneNo
				+ ", smsCode=" + smsCode + ", notifyUrl=" + notifyUrl + ", extend=" + extend + "]";
	}

}
