package com.sand.domain;

import java.io.Serializable;

/**
 * 公共报文
 * 
 * @author moon
 */
public class PubRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	private String version;
	private String method;
	private String productId;
	private String accessType;
	private String mid;
	private String plMid;
	private String channelType;
	private String reqTime;
	private String clientIP;

	public PubRequest() {
		super();
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getPlMid() {
		return plMid;
	}

	public void setPlMid(String plMid) {
		this.plMid = plMid;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getReqTime() {
		return reqTime;
	}

	public void setReqTime(String reqTime) {
		this.reqTime = reqTime;
	}

	public String getClientIP() {
		return clientIP;
	}

	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}

	@Override
	public String toString() {
		return "PubRequest [version=" + version + ", method=" + method + ", productId=" + productId + ", accessType="
				+ accessType + ", mid=" + mid + ", plMid=" + plMid + ", channelType=" + channelType + ", reqTime="
				+ reqTime + ", clientIP=" + clientIP + "]";
	}

}
