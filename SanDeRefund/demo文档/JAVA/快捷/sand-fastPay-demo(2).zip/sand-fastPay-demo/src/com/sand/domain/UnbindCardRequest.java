package com.sand.domain;

/**
 * 解绑卡请求对象
 * 
 * @author moon
 *
 */
public class UnbindCardRequest extends PubRequest {
	private static final long serialVersionUID = 1L;
	private String userId;
	private String applyNo;
	private String bid;
	private String notifyUrl;
	private String extend;

	public UnbindCardRequest() {
		super();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getApplyNo() {
		return applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

	@Override
	public String toString() {
		return "UnbindCardRequest [userId=" + userId + ", applyNo=" + applyNo + ", bid=" + bid + ", notifyUrl="
				+ notifyUrl + ", extend=" + extend + "]";
	}

}
