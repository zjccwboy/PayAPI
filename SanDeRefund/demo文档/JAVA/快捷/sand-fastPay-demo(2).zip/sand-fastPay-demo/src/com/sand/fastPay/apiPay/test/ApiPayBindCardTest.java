package com.sand.fastPay.apiPay.test;

import java.util.Date;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sand.common.AbstractTest;
import com.sand.common.DateUtil;
import com.sand.common.SandConfig;
import com.sand.domain.ApplyBindCardRequest;
import com.sand.domain.PubRequest;

/**
 * 快速绑卡接入示例
 */
public class ApiPayBindCardTest extends AbstractTest {

	private final Logger logger = LoggerFactory.getLogger(ApiPayBindCardTest.class);

	/*
	 * 快速绑卡请求URL
	 */
	private static final String URL = SandConfig.getConfig().getApiBindCardUrl();

	/**
	 * 快速绑卡接口调用示例 说明：
	 * 1、商户接入需加载公私钥到项目中 
	 * 2、封装调用杉德服务端接口，具体参数说明请参考接入文档
	 * 3、POST请求杉德服务端
	 * 4、验证杉德返回数据签名
	 */
	@Test
	public void createOrderTest() {

		try {
			// 组织申请绑卡HEAD域
			PubRequest requestHead = new PubRequest();
			requestHead.setVersion("1.0");
			requestHead.setMethod("sandPay.fastPay.apiPay.bindCard");
			requestHead.setProductId("00000018");
			requestHead.setAccessType("1");
			requestHead.setMid("10020034");
			requestHead.setPlMid("");
			requestHead.setChannelType("07");
			requestHead.setReqTime(DateUtil.fDate_YYYYMMDDHHMMSS(new Date()));

			// 组织申请绑卡BODY域
			ApplyBindCardRequest requestBody = new ApplyBindCardRequest();
			requestBody.setUserId("0000011111");
			requestBody.setCardNo("6230580000111100020");
			requestBody.setUserName("张三");
			requestBody.setApplyNo("111111" + String.valueOf(Math.round(Math.random() * 899999 + 100000)));
			requestBody.setPhoneNo("13800001111");
			requestBody.setCertificateNo("320828190011112222");
			requestBody.setCertificateType("01");
			requestBody.setCreditFlag("1");
			// 贷记卡必填
            // requestBody.setCheckNo("");
            // requestBody.setCheckExpiry("");
			requestBody.setExtend("");
			doPost(requestHead, requestBody, URL);
		} catch (Exception e) {
			logger.error("快速绑卡失败,{}", e);
		}
	}
}
