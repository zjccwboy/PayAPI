package com.sand.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sand.common.SandConfig;

import cn.com.sandpay.cashier.sdk.util.CertUtil;

/**
 * 加载证书
 * @author moon
 *
 */
public class ContextLoadListener implements ServletContextListener {

    private static final Logger logger = LoggerFactory.getLogger(ContextLoadListener.class);

    public void contextDestroyed(ServletContextEvent arg0) {
    }

    /**
     * 初始化密钥
     * @param arg0
     */
    public void contextInitialized(ServletContextEvent arg0) {
    	
    	SandConfig.getConfig().loadConfigFromSrc();
    	String sandPubCertPath = SandConfig.getConfig().getSandPubCertPath();
		String midPriCertPath = SandConfig.getConfig().getMidPriCertPath();
		String midPriCertPwd = SandConfig.getConfig().getMidPriCertPwd();

        // 加载证书
        try {
            logger.info("==>开始加载证书, sandPubCertPath:{}, midPriCertPath:{}, midPriCertPwd不显示", sandPubCertPath, midPriCertPath);
            CertUtil.init(sandPubCertPath, midPriCertPath, midPriCertPwd);
            logger.info("<==结束加载证书");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
