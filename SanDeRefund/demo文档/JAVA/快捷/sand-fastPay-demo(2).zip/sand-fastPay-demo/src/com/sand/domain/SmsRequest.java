package com.sand.domain;

/**
 * 发送支付短信请求对象
 * 
 * @author moon
 *
 */
public class SmsRequest extends PubRequest {

	private static final long serialVersionUID = 1L;
	private String userId;
	private String orderCode;
	private String phoneNo;
	private String bid;
	private String extend;

	public SmsRequest() {
		super();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getExtend() {
		return extend;
	}

	public void setExtend(String extend) {
		this.extend = extend;
	}

	@Override
	public String toString() {
		return "SmsRequest [userId=" + userId + ", orderCode=" + orderCode + ", phoneNo=" + phoneNo + ", bid=" + bid
				+ ", extend=" + extend + "]";
	}

}
